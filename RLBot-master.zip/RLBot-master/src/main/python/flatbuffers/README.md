This is not our code. It comes from here: https://github.com/google/flatbuffers/tree/v1.9.0

We'd love to be getting it from PyPI instead of storing it here,
but the maintainers aren't super enthusiastic about vending software.
https://github.com/google/flatbuffers/issues/4507