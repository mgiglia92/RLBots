﻿using System.Threading;

namespace RLBotDotNet
{
    internal struct BotProcess
    {
        public Bot bot;
        public Thread thread;
    }
}
