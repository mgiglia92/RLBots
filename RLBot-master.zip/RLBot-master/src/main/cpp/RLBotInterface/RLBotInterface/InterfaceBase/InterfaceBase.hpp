#ifndef INTERFACEBASE_HPP
#define INTERFACEBASE_HPP

#define DLL_EXPORT		__declspec(dllexport)
#define RLBOT_CORE_API	__cdecl

#endif