#pragma once

struct ByteBuffer
{
	void* ptr;
	int size;
};