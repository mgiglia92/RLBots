# Leviathan
ML-bot for Rocket League
# setup instructions
1. setup RLBot -> rlbot.org
2. install pytorch -> pytorch.org
3. start run.bat
